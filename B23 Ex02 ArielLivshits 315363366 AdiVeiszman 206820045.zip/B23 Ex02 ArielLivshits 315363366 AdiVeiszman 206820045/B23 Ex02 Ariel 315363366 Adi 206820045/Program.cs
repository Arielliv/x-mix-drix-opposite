﻿namespace B23_Ex02_Ariel_315363366_Adi_206820045
{
    public class Program
    {
        public static void Main()
        {
            UserInterface userInterface = new UserInterface();
            userInterface.StartGamesSession();
        }
    }
}
